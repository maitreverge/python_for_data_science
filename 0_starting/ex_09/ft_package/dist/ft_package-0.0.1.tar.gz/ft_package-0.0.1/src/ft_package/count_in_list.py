def count_in_list(lst: list, needle) -> int:
    """
    Return the occurence number of `needle` in `lst`.
    """
    return(lst.count(needle))